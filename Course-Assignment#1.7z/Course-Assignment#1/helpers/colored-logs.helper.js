export const styledLog = (color, text) => console.log(color + text);
